
class Strings {
  static const String appName = "Employee Directory";
  static const String employeeList = "Employees List";
  static const String employeeDetails = "Employee Details";
  static const String address = "Address";
  static const String company = "Company";
  static const String website = "Website";
  static const String notAvailable = "Not available";
  static const String search = "Search name or email";

}