import 'dart:ui';
import 'package:flutter/material.dart';

const colorPrimary = Color(0xff25CBEB);
const colorPrimaryDark = Color(0xff237B83);
const gradient1 = Color(0xFF63D3BB);
const gradient2 = Color(0xFF73C3EB);
const gradient3 = Color(0xFF25CBEB);
const textColor = Color(0xFF333333);
const lineColor = Color(0xFFECECEC);
const primeGreen = Color(0xFF63D3BB);
const colorGreen = Color(0xFF05E800);
const green2 = Color(0xFF4EC04C);
const colorYellow = Color(0xFFCDA000);
const colorYellow2 = Color(0xFFEAC43E);
const green3 = Color(0xFF2EA7B2);
const greyColor4 = Color(0xFF707070);
const lineColour = Color(0xFF9F9B9B);

