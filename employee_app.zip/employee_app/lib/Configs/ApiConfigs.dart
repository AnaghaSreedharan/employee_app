class ApiConfigs {
  // ignore: non_constant_identifier_names
  static String BASE_URL = "http://www.mocky.io/";
  // ignore: non_constant_identifier_names
  static String API_URL = BASE_URL + "v2/";
  static String IMAGE_URL = "http://www.mocky.io/";
}

class ApiEndPoints {
  static String getEmployeesList = "5d565297300000680030a986";
}
